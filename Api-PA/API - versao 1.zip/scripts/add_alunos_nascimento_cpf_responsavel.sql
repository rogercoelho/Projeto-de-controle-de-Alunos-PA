-- Script para adicionar as colunas Alunos_Data_Nascimento e Alunos_CPF_Responsavel na tabela Alunos_Cadastros
ALTER TABLE Alunos_Cadastros
  ADD COLUMN Alunos_Data_Nascimento VARCHAR(50) NOT NULL AFTER Alunos_CPF,
  ADD COLUMN Alunos_CPF_Responsavel VARCHAR(50) NULL AFTER Alunos_Nome_Responsavel;
